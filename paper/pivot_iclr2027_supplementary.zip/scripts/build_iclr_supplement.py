#!/usr/bin/env python3
"""Build a deterministic, anonymized ICLR supplementary archive."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import sys
import zipfile
from pathlib import Path

# Keep the documented ``python scripts/...`` entry point independent of an
# editable install.  The repository root is the package import root for the
# V15 experiment modules.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from experiments.v15.planes import redact_task_manifest
from scripts.paper_assets import manuscript_assets

ALLOWLIST = (
    "src",
    "scripts",
    "experiments",
    "configs",
    "results/theory",
    "results/v7",
    "results/v9",
    "results/v15",
    "figures/v9",
    "figures/v10",
    "figures/v15",
    "tables/v9",
    "artifacts/v9",
    "artifacts/v10",
    "artifacts/v15",
    "snapshot/v9_preupgrade",
    "research",
    "tests",
    "benchmarks/improvementbench/v1",
    "benchmarks/improvementbench/v2",
    "benchmarks/improvementbench/v7",
    "paper/figures/v10_style.py",
    "paper/figures/scientific_figure_style.json",
)
TEXT_SUFFIXES = {".py", ".yaml", ".yml", ".json", ".jsonl", ".ndjson", ".md", ".tex", ".bib", ".txt", ".csv"}
SKIP_PARTS = {
    "__pycache__",
    ".pytest_cache",
    ".ruff_cache",
    ".mypy_cache",
    ".venv",
    "build",
    "pivot_research.egg-info",
    (".co" "dex"),
}
# Split signatures so release sanitization cannot rewrite its own rules.
PRIVATE_RE = re.compile(r"(?:/opt/" r"projects|/home/" r"ubuntu|/t" r"mp(?:/[A-Za-z0-9_.-]*)?)")
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
ASSISTANT_RE = re.compile(r"co" r"dex", flags=re.IGNORECASE)
API_BASE_FIELD_RE = re.compile(r'("api_base"\s*:\s*)"[^"]*"', flags=re.IGNORECASE)
PUBLIC_PARQUET_PREFIXES = (
    "results/v15/canonical/",
    "figures/v15/",
    "artifacts/v15/",
    "paper/figures/release/",
)
SEALED_HISTORY_RELATIVE = "experiments/v15/confirmatory_lock_history.jsonl"
SEALED_MANIFEST_RELATIVE = "configs/v15/task_manifest.json"
SEALED_LOCK_RELATIVE = "experiments/v15/confirmatory_lock.json"
PUBLIC_MANIFEST_RELATIVE = "configs/v15/task_manifest.public.json"

# The latest sealed response-world evidence is copied into a small, explicit
# public subtree. Keep these paths relative to the checkout so the constant
# is useful both to the builder and to unit tests without exposing machine
# roots in generated artifacts.
LATEST_EVIDENCE_SOURCES = {
    "melting_v4": Path(
        "artifacts/revision/iclr_20260918/source/07_下一步_PIVOTv2_异质响应/"
        "server_results/melting_v4_confirm_analysis"
    ),
    "leduc_v2b": Path(
        "artifacts/revision/iclr_20260918/source/07_下一步_PIVOTv2_异质响应/"
        "server_results/openspiel_v2_20260918/reanalysis_v12/leduc_v2b_confirm"
    ),
    "kuhn_v2b": Path(
        "artifacts/revision/iclr_20260918/source/07_下一步_PIVOTv2_异质响应/"
        "server_results/openspiel_v2_20260918/reanalysis_v12/kuhn_v2b_confirm"
    ),
}
LATEST_EVIDENCE_FILES = (
    "summary.json",
    "seed_results.csv",
    "decisions_sealed.json",
    "scored_decisions.json",
    "posterior_v2_spec.json",
    "selection_seal.json",
)
LATEST_EVIDENCE_AUDIT = Path("paper/revision_evidence_public.json")
DECISION_RELEVANCE_DIR = Path("artifacts/revision/20260920-manuscript-update")
SUPPLEMENT_EXCLUDED = {
    Path("scripts/build_revision_evidence.py"),
    Path("paper/revision_evidence_manifest.json"),
}
MULTIROUND_ARTIFACT_FILES = (
    "pyproject.toml",
    "docs/rebuttal/audit/run_p0_offline.py",
    "docs/rebuttal/audit/run_poker_sensitivity.py",
    "docs/rebuttal/audit/run_poker_calibration_bootstrap.py",
    "docs/rebuttal/audit/audit_poker_calibration_bootstrap.py",
    "docs/rebuttal/audit/run_highway_matched_physical.py",
    "docs/rebuttal/audit/run_highway_independent_physical.py",
    "docs/rebuttal/audit/aggregate_highway_calibration.py",
    "docs/rebuttal/audit/aggregate_highway_physical_results.py",
    "docs/rebuttal/audit/aggregate_highway_independent_physical.py",
    "docs/rebuttal/audit/audit_highway_independent_calibration.py",
    "docs/rebuttal/audit/run_multiround_loop.py",
    "docs/rebuttal/audit/run_multiround_loop_v2.py",
    "docs/rebuttal/audit/analyze_multiround_loop_v2.py",
    "docs/rebuttal/audit/run_multiround_loop_v3b.py",
    "docs/rebuttal/audit/run_multiround_loop_v3c.py",
    "docs/rebuttal/audit/analyze_multiround_loop_v3c.py",
    "docs/rebuttal/audit/audit_v3c_pressure_support.py",
    "docs/rebuttal/audit/audit_v3c_multidim_support.py",
    "docs/rebuttal/audit/validate_v3b_numerics.py",
    "docs/rebuttal/audit/freeze_multiround_loop_v3c.py",
    "docs/rebuttal/audit/audit_algorithm1_v3c_call_chain.py",
    "docs/rebuttal/audit/ALGORITHM1_V3C_CALL_CHAIN_AUDIT_20261114.md",
    "docs/rebuttal/audit/ALGORITHM1_V3C_CALL_CHAIN_AUDIT_20261114.json",
    "docs/rebuttal/audit/P1_LOOP_V3C_PROTOCOL_2026-11-10.md",
    "docs/rebuttal/audit/P1_LOOP_V2_PREREGISTRATION_2026-11-10.md",
    "docs/rebuttal/audit/V3C_CONFIRMATION_REPORT_2026-11-10.md",
    "docs/rebuttal/audit/P1_LOOP_V3C_PROTOCOL_CLARIFICATION_2026-11-10.md",
    "docs/rebuttal/audit/V3C_MULTIDIM_SUPPORT_REPORT_2026-11-10.md",
    "docs/rebuttal/audit/EXPERIMENT_PROTOCOL_MATRIX_2026-11-10.md",
    # Post-review matched-state diagnostic. It is kept separate from the v3c
    # confirmation because it was specified after the earlier results.
    "docs/rebuttal/audit/run_frozen_state_matched.py",
    "docs/rebuttal/audit/analyze_frozen_state_matched.py",
    "docs/rebuttal/audit/FROZEN_STATE_MATCHED_PREREGISTRATION_2026-11-10.md",
    "docs/rebuttal/audit/FROZEN_STATE_MATCHED_REPORT_2026-11-10.md",
    "docs/rebuttal/audit_inputs/highway_redesign/source-manifest.json",
    "results/rebuttal/20261110-p1-loop-v3c-confirmation-freeze.json",
    "results/rebuttal/20261110-p1-loop-v3c-numerics.json",
    "results/rebuttal/20261110-p1-loop-v3b-development/summary.json",
    "results/rebuttal/20261110-p1-loop-v3b-development/paired_analysis.json",
    "results/rebuttal/20261110-p1-loop-v3c-development/summary.json",
    "results/rebuttal/20261110-p1-loop-v3c-development/paired_analysis.json",
    "results/rebuttal/20261110-p1-loop-v3c-confirmation/calibration_model.json",
    "results/rebuttal/20261110-p1-loop-v3c-confirmation/calibration_rows.json",
    "results/rebuttal/20261110-p1-loop-v3c-confirmation/calibration_training_samples.json",
    "results/rebuttal/20261110-p1-loop-v3c-confirmation/freeze_binding.json",
    "results/rebuttal/20261110-p1-loop-v3c-confirmation/paired_analysis.json",
    "results/rebuttal/20261110-p1-loop-v3c-confirmation/pressure_support_diagnostic.json",
    "results/rebuttal/20261110-p1-loop-v3c-confirmation/multidim_support_diagnostic.json",
    "results/rebuttal/20261110-p1-loop-v3c-confirmation/protocol.json",
    "results/rebuttal/20261110-p1-loop-v3c-confirmation/summary.json",
    "results/rebuttal/20261110-p1-loop-v3c-confirmation/trajectory_ledger.json",
    "results/rebuttal/20261110-p1-loop-v3c-confirmation/trajectory_ledger.sha256",
    "results/rebuttal/20261110-p1-loop-v3c-confirmation/trajectories.json",
    "results/rebuttal/20261110-frozen-state-matched-v1/calibration_model.json",
    "results/rebuttal/20261110-frozen-state-matched-v1/calibration_rows.json",
    "results/rebuttal/20261110-frozen-state-matched-v1/calibration_training_samples.json",
    "results/rebuttal/20261110-frozen-state-matched-v1/paired_analysis.json",
    "results/rebuttal/20261110-frozen-state-matched-v1/protocol.json",
    "results/rebuttal/20261110-frozen-state-matched-v1/summary.json",
    "results/rebuttal/20261110-frozen-state-matched-v1/trajectory_ledger.json",
    "results/rebuttal/20261110-frozen-state-matched-v1/trajectory_ledger.sha256",
    "results/rebuttal/20261110-frozen-state-matched-v1/trajectories.json",
    # Post-review audits cited by the manuscript/rebuttal. Keep these
    # reviewer-facing reports with their sealed result summaries so each
    # quoted matched-baseline and calibration claim has public provenance.
    "docs/rebuttal/audit/P0_ANALYSIS_REPORT.md",
    "docs/rebuttal/audit/P0_B_POKER_SENSITIVITY_REPORT.md",
    "docs/rebuttal/audit/POKER_CALIBRATION_BOOTSTRAP_PREREG_2026-11-09.md",
    "docs/rebuttal/audit/POKER_CALIBRATION_BOOTSTRAP_REPORT_2026-11-09.md",
    "docs/rebuttal/audit/POKER_CALIBRATION_BOOTSTRAP_VERIFICATION_2026-11-09.json",
    "docs/rebuttal/audit/HIGHWAY_MATCHED_PHYSICAL_PREREGISTRATION_2026-11-09.md",
    "docs/rebuttal/audit/HIGHWAY_MATCHED_PHYSICAL_AUDIT_2026-11-09.md",
    "docs/rebuttal/audit/HIGHWAY_INDEPENDENT_PHYSICAL_PREREGISTRATION_2026-11-09.md",
    "docs/rebuttal/audit/HIGHWAY_INDEPENDENT_CALIBRATION_AUDIT_2026-11-09.md",
    "docs/rebuttal/audit/HIGHWAY_INDEPENDENT_VERIFICATION_2026-11-09.json",
    "docs/rebuttal/audit/HIGHWAY_OFFLINE_REPLAY.json",
    "docs/rebuttal/audit/P1_MULTIROUND_REPORT.md",
    "docs/rebuttal/audit/P1_LOOP_V3_V4_REPORT_2026-11-10.md",
    "docs/rebuttal/audit/P1_LOOP_V2_PREREGISTRATION_2026-11-10.md",
    "docs/rebuttal/audit/P1_LOOP_V3_PREREGISTRATION_2026-11-10.md",
    "docs/rebuttal/audit/P1_LOOP_V4_PREREGISTRATION_2026-11-10.md",
    "docs/rebuttal/audit/verify_completion.py",
    "results/rebuttal/20261109-p0-offline-v1/summary.json",
    "results/rebuttal/20261109-p0-offline-v2-500/summary.json",
    "results/rebuttal/20261109-p0-offline-v2-500/root-rows.json",
    "results/rebuttal/20261109-p0-offline-input-replay-v1/root-rows.json",
    "results/rebuttal/20261109-p0-poker-calibration-bootstrap-v1/summary.json",
    "results/rebuttal/20261109-p0-poker-calibration-bootstrap-v1/bootstrap_rows.json",
    "results/rebuttal/20261109-p0-poker-sensitivity-v3/summary.json",
    "results/rebuttal/20261109-p0-poker-sensitivity-v3/sensitivity_rows.json",
    "results/rebuttal/20261109-p0-poker-sensitivity-input-replay-v1/summary.json",
    "results/rebuttal/20261109-p1-loop-v1/summary.json",
    "results/rebuttal/20261109-p1-loop-v1/trajectory_ledger.json",
    "results/rebuttal/20261109-p1-loop-input-replay-v1/summary.json",
    "results/rebuttal/20261110-p1-loop-v2-confirmation/summary.json",
    "results/rebuttal/20261110-p1-loop-v2-confirmation/paired_analysis.json",
    "results/rebuttal/20261110-p1-loop-v2-confirmation/trajectory_ledger.json",
    "results/rebuttal/20261110-p1-loop-v2-confirmation/trajectory_ledger.sha256",
    "results/rebuttal/20261110-p1-loop-v2-confirmation/protocol.json",
    "results/rebuttal/20261110-p1-loop-v3-confirmation/static_calibration_model.json",
    "results/rebuttal/20261110-p1-loop-v4a-development/summary.json",
    "results/rebuttal/20261109-highway-matched-physical-v2/physical-aggregate-v2/summary.json",
    "results/rebuttal/20261109-highway-matched-physical-v2/physical-aggregate-v2/paired-root-results.json",
    "results/rebuttal/20261109-highway-independent-calibration-v1/aggregate/summary.json",
    "results/rebuttal/20261109-highway-independent-calibration-v1/aggregate/paired-root-results.json",
)
MULTIROUND_SOURCE_ROOT = Path("docs/rebuttal/audit_inputs/highway_redesign/source")
REBUTTAL_REPLAY_TREES = (
    "docs/rebuttal/audit_inputs/poker_v2b",
    "docs/rebuttal/audit_inputs/highway_redesign/evidence",
    "results/rebuttal/20261109-p0-poker-calibration-bootstrap-v1",
    "results/rebuttal/20261109-highway-matched-physical-v2/physical-aggregate-v2",
    "results/rebuttal/20261109-highway-matched-physical-v2/calibration-complete",
    "results/rebuttal/20261109-highway-independent-calibration-v1/aggregate",
)


def _is_public_parquet(relative: Path) -> bool:
    """Return whether a generated Parquet table is safe for the release."""

    normalized = relative.as_posix().lstrip("./")
    return any(normalized.startswith(prefix) for prefix in PUBLIC_PARQUET_PREFIXES)


def _is_public_v15_path(relative: Path) -> bool:
    """Keep V15 schemas and summaries, never raw sandbox/task executions."""

    parts = relative.as_posix().split("/")
    if len(parts) < 3 or parts[0:2] != ["results", "v15"]:
        return True
    if parts[2].startswith("dev-"):
        # DEV execution manifests expose counts and terminal states without
        # carrying task instructions.  Raw DEV rows are reproducible locally
        # but can embed prompts, traces, or final trees, so keep them private.
        return relative.name == "manifest.json"
    private_parts = {
        "artifacts",
        "inspect-logs",
        "final_tree",
        "agent-reviewer-artifacts",
        "agent-reviewer-logs",
    }
    if private_parts.intersection(parts):
        return False
    # JSONL manifests and candidate archives are useful; raw trajectory
    # streams are not. The latter are identified by their filename.
    if relative.suffix.casefold() in {".traj", ".jsonl"} and relative.name.endswith(".traj.json"):
        return False
    return not relative.name.endswith(".execution.json")


def _is_sealed_public_input(relative: Path) -> bool:
    """Return whether a path is a local-only sealed protocol input."""

    normalized = relative.as_posix().lstrip("./")
    return normalized in {SEALED_HISTORY_RELATIVE, SEALED_MANIFEST_RELATIVE}


def _sanitize_json_payload(
    relative: Path, payload: object, *, source_sha256: str | None = None
) -> object:
    """Remove hidden task contents from copied protocol JSON files."""

    normalized = relative.as_posix().lstrip("./")
    if normalized == SEALED_MANIFEST_RELATIVE and isinstance(payload, dict):
        return redact_task_manifest(payload, source_sha256=source_sha256)
    if normalized == SEALED_LOCK_RELATIVE and isinstance(payload, dict):
        cleaned = dict(payload)
        sealed = cleaned.get("sealed_planes")
        if isinstance(sealed, dict):
            cleaned["sealed_planes"] = redact_task_manifest(sealed)
        return cleaned
    return payload


def _copy_sanitized(source: Path, target: Path, relative: Path | None = None) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    if source.suffix.casefold() in TEXT_SUFFIXES:
        raw_text = source.read_text(encoding="utf-8", errors="replace")
        text = raw_text
        # Apply structural redaction before path/token substitutions so task
        # hashes remain hashes of the sealed source definitions.
        if source.suffix.casefold() == ".json" and relative is not None:
            try:
                payload = json.loads(raw_text)
            except json.JSONDecodeError:
                payload = None
            if payload is not None:
                text = json.dumps(
                    _sanitize_json_payload(
                        relative,
                        payload,
                        source_sha256=hashlib.sha256(raw_text.encode("utf-8")).hexdigest(),
                    ),
                    indent=2,
                    sort_keys=True,
                ) + "\n"
        text = PRIVATE_RE.sub("<local-root>", text)
        text = EMAIL_RE.sub("<redacted-email>", text)
        # The endpoint host is runtime infrastructure, not reproducibility
        # evidence.  Keep the field name while removing provider topology from
        # reviewer-facing artifacts.
        text = API_BASE_FIELD_RE.sub(r'\1"<external-endpoint>"', text)
        # Reviewer-facing artifacts must not disclose the internal editing
        # assistant.  Use an identifier-safe neutral token so copied Python
        # and JSON remain parseable where possible.
        text = ASSISTANT_RE.sub("implementation_assistant", text)
        target.write_text(text, encoding="utf-8")
    else:
        shutil.copyfile(source, target)


def build_supplement(project_root: Path, output_root: Path) -> list[Path]:
    """Copy the public allowlist and sanitize local provenance strings."""

    if output_root.exists():
        for path in sorted(output_root.rglob("*"), reverse=True):
            if path.is_file() or path.is_symlink():
                path.unlink()
            elif path.is_dir():
                path.rmdir()
    output_root.mkdir(parents=True, exist_ok=True)
    original_manifest = project_root / "paper" / "snapshot" / "manifest.json"
    original_manifest_sha256 = hashlib.sha256(original_manifest.read_bytes()).hexdigest()
    copied: list[Path] = []
    for root_name in ALLOWLIST:
        root = project_root / root_name
        if root.is_file():
            sources = [root]
        elif root.is_dir():
            sources = sorted(root.rglob("*"))
        else:
            # Historical provenance directories were pruned during the V15
            # migration. Their absence must not block the current release;
            # explicit current-paper/evidence copies below are authoritative.
            continue
        for source in sources:
            if not source.is_file() or any(part in SKIP_PARTS for part in source.parts):
                continue
            # Keep generated V15/figure parquet sources: they are compact,
            # schema-bearing artifacts rather than raw vendor archives.  Older
            # frozen archives and compressed blobs remain excluded.
            if source.suffix.casefold() in {".feather", ".zip", ".tar", ".gz"}:
                continue
            if source.suffix.casefold() == ".parquet" and not _is_public_parquet(
                source.relative_to(project_root)
            ):
                # Phase-level external tables retain executor paths for the
                # internal response audit.  Only the path-free canonical V15
                # tables and the already audited figure/artifact tables belong
                # in the anonymous release.
                continue
            relative = source.relative_to(project_root)
            if relative in SUPPLEMENT_EXCLUDED:
                continue
            if _is_sealed_public_input(relative):
                # Historical locks may contain pre-redaction task contents;
                # and the source task manifest contains gate/assessment
                # instructions.  Both are internal provenance and are not
                # needed by reviewers.
                continue
            if not _is_public_v15_path(relative):
                continue
            target = output_root / relative
            _copy_sanitized(source, target, relative)
            copied.append(target)
    for source in sorted((project_root / "paper" / "snapshot").rglob("*")):
        if not source.is_file():
            continue
        relative = Path("snapshot") / source.relative_to(project_root / "paper" / "snapshot")
        target = output_root / relative
        _copy_sanitized(source, target)
        copied.append(target)
    for name in ("controlled_results.tex", "public_results.tex", "ablation_results.tex"):
        source = project_root / "paper" / "tables" / name
        if not source.is_file():
            continue
        target = output_root / "tables" / name
        _copy_sanitized(source, target)
        copied.append(target)
    for relative_path in ("paper/results_macros.tex",):
        source = project_root / relative_path
        if not source.is_file():
            continue
        target = output_root / relative_path
        _copy_sanitized(source, target)
        copied.append(target)
    for relative_path in (
        "docs/v7-evidence-2026-08-25.md",
        "docs/external-environment-provenance.md",
        "docs/claim_boundary.md",
        "docs/archive/v15/V15_BASELINE_SNAPSHOT.md",
        "docs/archive/v15/V15_NUMBER_AUDIT.md",
        "docs/archive/v15/V15_FIGURE_STATUS.md",
        "docs/archive/v15/V15_REVIEWER_ATTACK_AUDIT.md",
        "docs/archive/v15/V15_CLAIM_AUDIT.md",
        "docs/archive/v15/V15_REFERENCE_AUDIT.md",
        "docs/archive/v15/V15_FINAL_REPORT.md",
        "docs/archive/v15/V15_SCIENTIFIC_SUMMARY.md",
        "docs/archive/v15/V15_TERMINAL_STATE_AUDIT.md",
        "docs/archive/v15/V15_REPRODUCIBILITY_AUDIT.md",
        "docs/archive/v15/V15_CONSTRUCT_VALIDITY.md",
        "snapshot/v15_pre_modern_agent/PROVENANCE.txt",
    ):
        source = project_root / relative_path
        if not source.is_file():
            continue
        target = output_root / relative_path
        _copy_sanitized(source, target)
        copied.append(target)

    # Current manuscript-facing sources and figures are copied explicitly so
    # the supplement follows the built PDF rather than a historical allowlist.
    paper_sources = manuscript_assets(project_root / "paper/main.tex")
    paper_sources.extend(project_root / name for name in (
        "paper/build_frozen.sh",
        "paper/README.md",
        "paper/style_manifest.json",
    ))
    for source in paper_sources:
        if not source.is_file():
            raise FileNotFoundError(source)
        relative_path = source.relative_to(project_root)
        target = output_root / relative_path
        _copy_sanitized(source, target, relative_path)
        copied.append(target)
    for source_root, target_root in (
        (project_root / "paper/style", output_root / "paper/style"),
        (project_root / "paper/tables", output_root / "paper/tables"),
        (project_root / "paper/figures/revision", output_root / "paper/figures/revision"),
        (project_root / "paper/figures/release", output_root / "paper/figures/release"),
    ):
        if not source_root.is_dir():
            continue
        for source in sorted(source_root.rglob("*")):
            if not source.is_file() or any(part in SKIP_PARTS for part in source.parts):
                continue
            relative = Path("paper") / source.relative_to(project_root / "paper")
            target = output_root / relative
            _copy_sanitized(source, target, relative)
            copied.append(target)

    # Preserve sealed evidence byte-for-byte: selection seals hash the exact
    # JSON payload, so the generic sanitizer must not reformat these files.
    for cohort, relative_source in LATEST_EVIDENCE_SOURCES.items():
        for name in LATEST_EVIDENCE_FILES:
            source = project_root / relative_source / name
            if not source.is_file():
                raise FileNotFoundError(source)
            target = output_root / "evidence/latest" / cohort / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            copied.append(target)
    audit_source = project_root / LATEST_EVIDENCE_AUDIT
    if audit_source.is_file():
        target = output_root / "evidence/latest/revision_evidence_audit.json"
        _copy_sanitized(audit_source, target)
        copied.append(target)
    for name in ("decision_relevance.json", "decision_relevance_rows.csv"):
        source = project_root / DECISION_RELEVANCE_DIR / name
        if source.is_file():
            target = output_root / "evidence/latest" / name
            _copy_sanitized(source, target)
            copied.append(target)

    # Keep the post-review multi-round study independently replayable. These
    # files are copied byte-for-byte because the analysis binds the ledger to
    # their exact hashes; the public source snapshot has no author metadata.
    for relative_path in MULTIROUND_ARTIFACT_FILES:
        source = project_root / relative_path
        if not source.is_file():
            raise FileNotFoundError(source)
        target = output_root / relative_path
        target.parent.mkdir(parents=True, exist_ok=True)
        if relative_path in {
            "results/rebuttal/20261109-p0-offline-v2-500/root-rows.json",
            "results/rebuttal/20261109-p0-offline-input-replay-v1/root-rows.json",
            "results/rebuttal/20261109-p1-loop-v1/trajectory_ledger.json",
            "results/rebuttal/20261109-highway-matched-physical-v2/physical-aggregate-v2/summary.json",
            "results/rebuttal/20261109-highway-matched-physical-v2/physical-aggregate-v2/paired-root-results.json",
            "results/rebuttal/20261109-highway-independent-calibration-v1/aggregate/summary.json",
            "results/rebuttal/20261109-highway-independent-calibration-v1/aggregate/paired-root-results.json",
        }:
            # These ledgers/summaries are hash-bound by independent audits.
            # The inspected source files contain no local paths.
            shutil.copyfile(source, target)
        elif relative_path == "results/rebuttal/20261110-p1-loop-v3c-numerics.json":
            numerical_audit = json.loads(source.read_text(encoding="utf-8"))
            numerical_audit["source"] = MULTIROUND_SOURCE_ROOT.as_posix()
            target.write_text(
                json.dumps(numerical_audit, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
        elif (
            relative_path.startswith("docs/rebuttal/audit/")
            or relative_path.startswith("results/rebuttal/")
            and relative_path.endswith("/summary.json")
        ):
            _copy_sanitized(source, target, Path(relative_path))
        else:
            shutil.copyfile(source, target)
        copied.append(target)
    source_root = project_root / MULTIROUND_SOURCE_ROOT
    if not source_root.is_dir():
        raise FileNotFoundError(source_root)
    for source in sorted(source_root.rglob("*")):
        if not source.is_file() or "__pycache__" in source.parts or source.suffix == ".pyc":
            continue
        relative = source.relative_to(project_root)
        target = output_root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        copied.append(target)
    # These public frozen inputs and decision ledgers were inspected for
    # anonymity. Keep their bytes intact so the embedded content manifests
    # and sealed-decision hashes remain verifiable after extraction.
    for tree in REBUTTAL_REPLAY_TREES:
        source_root = project_root / tree
        if not source_root.is_dir():
            raise FileNotFoundError(source_root)
        for source in sorted(source_root.rglob("*")):
            if not source.is_file() or any(part in SKIP_PARTS for part in source.parts):
                continue
            target = output_root / source.relative_to(project_root)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            copied.append(target)
    for name in (
        "calibration-model.json", "calibration-proxy-rows.json", "calibration-truth.json",
    ):
        relative = Path("results/rebuttal/20261109-highway-independent-calibration-v1/calibration") / name
        source = project_root / relative
        target = output_root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        copied.append(target)
    multiround_readme = output_root / "docs/rebuttal/audit/MULTIROUND_REPLAY_README.md"
    multiround_readme.parent.mkdir(parents=True, exist_ok=True)
    multiround_readme.write_text(
        "# Multi-round confirmation artifact\n\n"
        "The frozen v3c confirmation ledger and analysis are under\n"
        "`results/rebuttal/20261110-p1-loop-v3c-confirmation`. The exact runtime\n"
        "source snapshot is under `docs/rebuttal/audit_inputs/highway_redesign/source`;\n"
        "the protocol, runner, analyzer, numerical checks, and source/dependency\n"
        "freeze are included beside the audit report.\n\n"
        "From the archive root, run the independent replay with Python 3.12 and\n"
        "NumPy installed:\n\n"
        "```bash\n"
        ".venv/bin/python docs/rebuttal/audit/analyze_multiround_loop_v3c.py \\\n"
        "  --source docs/rebuttal/audit_inputs/highway_redesign/source \\\n"
        "  --input results/rebuttal/20261110-p1-loop-v3c-confirmation \\\n"
        "  --output v3c-replay.json --bootstrap-draws 10000 --signflip-draws 100000\n"
        ".venv/bin/python docs/rebuttal/audit/audit_v3c_pressure_support.py \\\n"
        "  --input results/rebuttal/20261110-p1-loop-v3c-confirmation --output v3c-pressure.json\n"
        ".venv/bin/python docs/rebuttal/audit/audit_v3c_multidim_support.py \\\n"
        "  --input results/rebuttal/20261110-p1-loop-v3c-confirmation \\\n"
        "  --output v3c-multidim-support.json --report v3c-multidim-support.md\n"
        ".venv/bin/python docs/rebuttal/audit/analyze_frozen_state_matched.py \\\n"
        "  --source docs/rebuttal/audit_inputs/highway_redesign/source \\\n"
        "  --input results/rebuttal/20261110-frozen-state-matched-v1 \\\n"
        "  --output frozen-state-replay.json --report frozen-state-replay.md\n"
        ".venv/bin/python docs/rebuttal/audit/validate_v3b_numerics.py \\\n"
        "  --source docs/rebuttal/audit_inputs/highway_redesign/source --output v3c-numerics.json\n"
        "```\n\n"
        "The one-shot confirmation is not rerun by these commands; the analyzer\n"
        "replays every stored decision against the runtime source and verifies\n"
        "the calibration model, query choices, outcomes, state transitions, and\n"
        "trajectory aggregates. The frozen-state matched diagnostic is a separate\n"
        "post-review auxiliary comparison; its null and mixed outcomes are retained\n"
        "and must not be pooled with the v3c confirmation.\n",
        encoding="utf-8",
    )
    copied.append(multiround_readme)
    _rewrite_snapshot_manifest(
        output_root / "snapshot" / "manifest.json",
        original_manifest_sha256,
    )

    # The public membership summary is intentionally required in the archive
    # so reviewers can verify plane counts and hashes without receiving the
    # sealed task files.  Fail closed if a future allowlist change drops it.
    public_manifest_target = output_root / PUBLIC_MANIFEST_RELATIVE
    if not public_manifest_target.is_file():
        raise FileNotFoundError(public_manifest_target)

    readme = output_root / "README.md"
    readme.write_text(
        """# IMPROVE-X / PIVOT ICLR 2027 Supplementary Artifact

This archive contains the anonymous source, public configurations, tests, the
controlled ImprovementBench releases, the current manuscript sources, and the
hash-indexed paper snapshot used for the submission PDF. The three sealed
response-world cohorts (Leduc, Kuhn, and Melting Pot) are copied byte-for-byte
under `evidence/latest`; the public audit and decision-relevance bridge are
included alongside them. Sealed task instructions and lock history remain
local; only the redacted task-membership summary is included.
For a frozen paper-only rebuild, install TeX Live (including texlive-science),
latexmk, Poppler, and Python 3.10 or newer, then run from the archive root:

```bash
bash paper/build_frozen.sh
```

This compiles the included, already audited tables and figures and validates
the rendered PDF. It does not regenerate experimental evidence or need private
archives. The source and every referenced graphic are included under `paper/`.
The historical hash-indexed snapshot is under `snapshot/`, not `paper/snapshot/`.
For analyses, create a Python environment and install the project with
`python -m pip install -e '.[dev]'`; the multi-round replay commands and scope
are documented in `docs/rebuttal/audit/MULTIROUND_REPLAY_README.md`.

The strong-baseline and calibration runners are under `docs/rebuttal/audit/`.
Normalized poker banks and Highway saved-truth inputs are included under
`docs/rebuttal/audit_inputs/`. The 500 poker refits retain their sealed
decisions, scored rows, and content manifest; the two fresh Highway cohorts
retain aggregate decision/query/truth/cost ledgers and calibration models.
The original full physical-provenance auditor also needs per-shard runtime
journals; its recorded audit report is included, while this compact release
contains the aggregate ledgers. See the protocols for the simulator reruns.

The public finance audit uses virtual fills and observational depth
proxies. No credentials, private data, raw vendor archives, live
orders, or author identity metadata are included.

The controlled value-versus-improvement diagnostic can be regenerated with:

```bash
.venv/bin/python experiments/e4_value_vs_improvement.py \\
  --config configs/sweeps/e4_value_vs_improvement.yaml \\
  --output artifacts/v9/reproduction/e4-value-vs-improvement
```

This is a controlled estimand diagnostic, not a universal method or market
performance claim.

Earlier controlled checks and frozen external classifications remain under
`results/theory` and `results/v7` for provenance. Decompress a row stream with
`gzip -dk transition_rows.jsonl.gz` when a row-level audit is needed. The
analytic checks can be regenerated with:

```bash
.venv/bin/python experiments/e10_theory_empirical.py \\
  --config configs/theory/v6_empirical.yaml \\
  --output artifacts/v9/reproduction/e10-theory-empirical
```

They test the constructive Global Fidelity Blindness and Response-Footprint
Sensitivity claims; they are not causal market evidence.

The evidence archive is a frozen copy, not a rerun. The supplementary builder
in `scripts/build_iclr_supplement.py` is the author-side release entry point;
it expects the full evidence checkout, including the original sealed cohort
locations. To compile this extracted archive, use the frozen build above.

The manuscript reports the scientific names of the evidence layers. Internal
run identifiers are retained only in manifests and source metadata.

The editable architecture source is adapted from the pinned OpenTikZ
`system-block-diagram` template. Rebuild it after installing the lock-bound
checkout with `scripts/bootstrap_opentikz.py` and
`scripts/build_opentikz_architecture.py`.
""",
        encoding="utf-8",
    )
    copied.append(readme)
    return sorted(set(copied))


def _rewrite_snapshot_manifest(path: Path, original_sha256: str) -> None:
    """Bind manifest hashes to sanitized files in the supplement."""

    manifest = json.loads(path.read_text(encoding="utf-8"))
    for relative, entry in manifest.get("files", {}).items():
        candidate = path.parent / relative
        if not candidate.is_file():
            raise FileNotFoundError(candidate)
        entry["sha256"] = hashlib.sha256(candidate.read_bytes()).hexdigest()
        entry["size_bytes"] = candidate.stat().st_size
    manifest["source_roots"] = {key: "<local-root>" for key in manifest.get("source_roots", {})}
    manifest["sanitized_for_submission"] = True
    manifest["original_manifest_sha256"] = original_sha256
    path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_deterministic_zip(root: Path, archive: Path) -> str:
    """Write sorted files with fixed timestamps and return SHA-256."""

    archive.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for path in sorted(p for p in root.rglob("*") if p.is_file()):
            relative = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(relative, date_time=(2020, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            output.writestr(info, path.read_bytes())
    return hashlib.sha256(archive.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description="Build PIVOT ICLR supplementary archive")
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    args = parser.parse_args()
    files = build_supplement(args.project_root.resolve(), args.output_root.resolve())
    manifest = {
        "schema_version": "pivot-anonymous-supplement-manifest-2",
        "file_count": len(files) + 1,
        "archive": args.archive.name,
        # The archive digest cannot be embedded in the archive without making
        # the digest self-referential.  Keep the in-archive value explicit and
        # publish the computed digest in the sidecar manifest below.
        "archive_sha256": None,
        "snapshot_manifest_sha256": hashlib.sha256(
            (args.output_root / "snapshot" / "manifest.json").read_bytes()
        ).hexdigest(),
        "allowlist": list(ALLOWLIST)
        + ["paper/snapshot", "paper/tables", "paper/results_macros.tex"],
        "manuscript_assets": [
            path.relative_to(args.project_root.resolve()).as_posix()
            for path in manuscript_assets(args.project_root / "paper/main.tex")
        ],
        "frozen_build_command": "bash paper/build_frozen.sh",
    }
    # Put a self-describing manifest inside the archive.  The archive digest is
    # intentionally kept in the sidecar below because embedding it would make
    # the digest self-referential.
    manifest_path = args.output_root / "supplement_manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    digest = write_deterministic_zip(args.output_root.resolve(), args.archive.resolve())
    sidecar = {**manifest, "archive_sha256": digest, "manifest_inside_archive": True}
    manifest_path.write_text(json.dumps(sidecar, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(sidecar, sort_keys=True))


if __name__ == "__main__":
    main()
