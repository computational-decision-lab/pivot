# Baseline Snapshot

Status: **BLOCKED**

The pre-modern-agent fallback is preserved before any new edits.  Git commit:
`2ea1246230eda7ce2f645d2e12774db883a79a72` (from the snapshot provenance).  The exact tracked subtree is stored in
`snapshot/v15_pre_modern_agent/source/research-pivot-head.tar`; key PDF,
source, bibliography, supplement, and macro copies plus SHA-256 provenance are
under `snapshot/v15_pre_modern_agent/key_artifacts`.

PDF: `df6d5b1e5d38d21445270f50e33a2723223e7794bfec2962fc12b3523cb87c07`
Provenance file: `fa48e2137576025828953672fb92cef79a3fc83bcaedc15102232119d0d28258`
