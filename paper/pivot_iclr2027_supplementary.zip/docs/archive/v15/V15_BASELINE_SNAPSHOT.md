# Baseline Snapshot

Status: **BLOCKED**

The pre-modern-agent fallback is preserved before any new edits.  Git commit:
`2ea1246230eda7ce2f645d2e12774db883a79a72` (from the snapshot provenance).  The exact tracked subtree is stored in
`snapshot/v15_pre_modern_agent/source/research-pivot-head.tar`; key PDF,
source, bibliography, supplement, and macro copies plus SHA-256 provenance are
under `snapshot/v15_pre_modern_agent/key_artifacts`.

PDF: `39aa58550825366e45ea0e5c2dd94d8b40092f4c07d062f3e4503979c11a3a70`
Provenance file: `fa48e2137576025828953672fb92cef79a3fc83bcaedc15102232119d0d28258`
