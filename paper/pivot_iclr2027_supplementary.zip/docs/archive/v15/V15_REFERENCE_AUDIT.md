# Reference Audit

Status: **PASS**.

The bundled bibliography contains `75`
entries, of which `25` are cited in
the manuscript.  Duplicate keys: `[]`;
missing citation keys: `[]`.
Recent preprints remain labelled as preprints; this local key audit does not
claim that every external metadata record is a peer-reviewed venue record.
