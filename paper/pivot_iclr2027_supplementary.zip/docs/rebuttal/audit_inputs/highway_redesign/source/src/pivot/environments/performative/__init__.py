"""Controlled performative environment."""
