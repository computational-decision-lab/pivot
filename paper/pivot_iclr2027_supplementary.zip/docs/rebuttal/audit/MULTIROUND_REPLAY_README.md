# Multi-round confirmation artifact

The frozen v3c confirmation ledger and analysis are under
`results/rebuttal/20261110-p1-loop-v3c-confirmation`. The exact runtime
source snapshot is under `docs/rebuttal/audit_inputs/highway_redesign/source`;
the protocol, runner, analyzer, numerical checks, and source/dependency
freeze are included beside the audit report.

From the archive root, run the independent replay with Python 3.12 and
NumPy installed:

```bash
.venv/bin/python docs/rebuttal/audit/analyze_multiround_loop_v3c.py \
  --source docs/rebuttal/audit_inputs/highway_redesign/source \
  --input results/rebuttal/20261110-p1-loop-v3c-confirmation \
  --output v3c-replay.json --bootstrap-draws 10000 --signflip-draws 100000
.venv/bin/python docs/rebuttal/audit/audit_v3c_pressure_support.py \
  --input results/rebuttal/20261110-p1-loop-v3c-confirmation --output v3c-pressure.json
.venv/bin/python docs/rebuttal/audit/audit_v3c_multidim_support.py \
  --input results/rebuttal/20261110-p1-loop-v3c-confirmation \
  --output v3c-multidim-support.json --report v3c-multidim-support.md
.venv/bin/python docs/rebuttal/audit/analyze_frozen_state_matched.py \
  --source docs/rebuttal/audit_inputs/highway_redesign/source \
  --input results/rebuttal/20261110-frozen-state-matched-v1 \
  --output frozen-state-replay.json --report frozen-state-replay.md
.venv/bin/python docs/rebuttal/audit/validate_v3b_numerics.py \
  --source docs/rebuttal/audit_inputs/highway_redesign/source --output v3c-numerics.json
```

The one-shot confirmation is not rerun by these commands; the analyzer
replays every stored decision against the runtime source and verifies
the calibration model, query choices, outcomes, state transitions, and
trajectory aggregates. The frozen-state matched diagnostic is a separate
post-review auxiliary comparison; its null and mixed outcomes are retained
and must not be pooled with the v3c confirmation.
