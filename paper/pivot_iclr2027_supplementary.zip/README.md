# IMPROVE-X / PIVOT ICLR 2027 Supplementary Artifact

This archive contains the anonymous source, public configurations, tests, the
controlled ImprovementBench releases, the current manuscript sources, and the
hash-indexed paper snapshot used for the submission PDF. The three sealed
response-world cohorts (Leduc, Kuhn, and Melting Pot) are copied byte-for-byte
under `evidence/latest`; the public audit and decision-relevance bridge are
included alongside them. Sealed task instructions and lock history remain
local; only the redacted task-membership summary is included.
For a frozen paper-only rebuild, install TeX Live (including texlive-science),
latexmk, Poppler, and Python 3.10 or newer, then run from the archive root:

```bash
bash paper/build_frozen.sh
```

This compiles the included, already audited tables and figures and validates
the rendered PDF. It does not regenerate experimental evidence or need private
archives. The source and every referenced graphic are included under `paper/`.
The historical hash-indexed snapshot is under `snapshot/`, not `paper/snapshot/`.
For analyses, create a Python environment and install the project with
`python -m pip install -e '.[dev]'`; the multi-round replay commands and scope
are documented in `docs/rebuttal/audit/MULTIROUND_REPLAY_README.md`.

The strong-baseline and calibration runners are under `docs/rebuttal/audit/`.
Normalized poker banks and Highway saved-truth inputs are included under
`docs/rebuttal/audit_inputs/`. The 500 poker refits retain their sealed
decisions, scored rows, and content manifest; the two fresh Highway cohorts
retain aggregate decision/query/truth/cost ledgers and calibration models.
The original full physical-provenance auditor also needs per-shard runtime
journals; its recorded audit report is included, while this compact release
contains the aggregate ledgers. See the protocols for the simulator reruns.

The public finance audit uses virtual fills and observational depth
proxies. No credentials, private data, raw vendor archives, live
orders, or author identity metadata are included.

The controlled value-versus-improvement diagnostic can be regenerated with:

```bash
.venv/bin/python experiments/e4_value_vs_improvement.py \
  --config configs/sweeps/e4_value_vs_improvement.yaml \
  --output artifacts/v9/reproduction/e4-value-vs-improvement
```

This is a controlled estimand diagnostic, not a universal method or market
performance claim.

Earlier controlled checks and frozen external classifications remain under
`results/theory` and `results/v7` for provenance. Decompress a row stream with
`gzip -dk transition_rows.jsonl.gz` when a row-level audit is needed. The
analytic checks can be regenerated with:

```bash
.venv/bin/python experiments/e10_theory_empirical.py \
  --config configs/theory/v6_empirical.yaml \
  --output artifacts/v9/reproduction/e10-theory-empirical
```

They test the constructive Global Fidelity Blindness and Response-Footprint
Sensitivity claims; they are not causal market evidence.

The evidence archive is a frozen copy, not a rerun. The supplementary builder
in `scripts/build_iclr_supplement.py` is the author-side release entry point;
it expects the full evidence checkout, including the original sealed cohort
locations. To compile this extracted archive, use the frozen build above.

The manuscript reports the scientific names of the evidence layers. Internal
run identifiers are retained only in manifests and source metadata.

The editable architecture source is adapted from the pinned OpenTikZ
`system-block-diagram` template. Rebuild it after installing the lock-bound
checkout with `scripts/bootstrap_opentikz.py` and
`scripts/build_opentikz_architecture.py`.
