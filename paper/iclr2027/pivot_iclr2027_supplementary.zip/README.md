# IMPROVE-X / PIVOT ICLR 2027 Supplementary Artifact

This archive contains the anonymous source, configurations, tests, the
controlled ImprovementBench v1/v2 releases, and the hash-indexed paper
snapshot used for the submission PDF. From the
repository root, install the project in editable mode and run:

```bash
.venv/bin/pytest -q
.venv/bin/ruff check .
.venv/bin/python scripts/build_paper_tables.py --snapshot paper/snapshot --output paper/tables
```

The public finance audit uses virtual fills and observational depth
proxies. No credentials, private data, raw vendor archives, live
orders, or author identity metadata are included.
