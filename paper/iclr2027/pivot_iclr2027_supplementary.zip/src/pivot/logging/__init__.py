"""Auditable transition artifact storage."""
