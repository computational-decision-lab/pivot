"""Improvement fidelity metrics."""
