#!/usr/bin/env python3
"""Describe or explicitly authorize guarded Tencent CVM lifecycle actions."""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any

# Allow direct invocation from a checkout without installing the package.
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from pivot.cloud.tencent_lifecycle import TencentResourceLifecycle
from pivot.cloud.tencent_lifecycle import AuthorizationError, ProtectedResourceError, ResourceNotFoundError


class TencentSdkClient:
    """Small adapter around the Tencent CVM SDK, imported only when needed."""

    def __init__(self, region: str) -> None:
        try:
            from tencentcloud.common import credential
            from tencentcloud.common.profile.client_profile import ClientProfile
            from tencentcloud.common.profile.http_profile import HttpProfile
            from tencentcloud.cvm.v20170312 import cvm_client, models
        except ImportError as exc:
            raise RuntimeError("Tencent CVM SDK is unavailable") from exc
        secret_id = os.environ.get("TENCENTCLOUD_SECRET_ID")
        secret_key = os.environ.get("TENCENTCLOUD_SECRET_KEY")
        if not secret_id or not secret_key:
            raise RuntimeError("Tencent credentials are unavailable")
        self._models = models
        self._client = cvm_client.CvmClient(credential.Credential(secret_id, secret_key), region, ClientProfile(HttpProfile()))

    def _call(self, request: Any, response_type: Any) -> dict[str, Any]:
        response = response_type.to_json(self._client._call("")) if False else None
        del response
        raise NotImplementedError

    def describe_instances(self, instance_ids=None):
        req = self._models.DescribeInstancesRequest()
        if instance_ids:
            req.InstanceIds = list(instance_ids)
        return json.loads(self._client.DescribeInstances(req).to_json_string())

    def start_instances(self, instance_ids):
        req = self._models.StartInstancesRequest()
        req.InstanceIds = list(instance_ids)
        return json.loads(self._client.StartInstances(req).to_json_string())

    def stop_instances(self, instance_ids):
        req = self._models.StopInstancesRequest()
        req.InstanceIds = list(instance_ids)
        return json.loads(self._client.StopInstances(req).to_json_string())

    def terminate_instances(self, instance_ids):
        req = self._models.TerminateInstancesRequest()
        req.InstanceIds = list(instance_ids)
        return json.loads(self._client.TerminateInstances(req).to_json_string())


def _parse_tags(values: list[str]) -> dict[str, str]:
    tags: dict[str, str] = {}
    for value in values:
        key, separator, tag_value = value.partition("=")
        if not separator or not key:
            raise ValueError("--tag values must use key=value")
        tags[key] = tag_value
    return tags


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--region", default="ap-tokyo")
    parser.add_argument("--action", choices=("describe", "start", "stop", "release"), default="describe")
    parser.add_argument("--instance-id")
    parser.add_argument("--owner")
    parser.add_argument("--tag", action="append", default=[])
    parser.add_argument("--dry-run", action="store_true", help="authorize and preview a mutation")
    parser.add_argument("--execute", action="store_true", help="perform a mutation after all guards pass")
    args = parser.parse_args()
    if args.dry_run and args.execute:
        parser.error("--dry-run and --execute are mutually exclusive")
    if args.action != "describe":
        if not args.instance_id or not args.owner:
            parser.error("mutating actions require --instance-id and --owner")
        if not args.dry_run and not args.execute:
            parser.error("mutating actions require explicit --dry-run or --execute")
    try:
        lifecycle = TencentResourceLifecycle(TencentSdkClient(args.region))
        if args.action == "describe":
            result = lifecycle.describe(args.instance_id)
        else:
            result = lifecycle.mutate(
                args.action,
                args.instance_id,
                owner=args.owner,
                tags=_parse_tags(args.tag),
                dry_run=not args.execute,
            )
    except (AuthorizationError, ProtectedResourceError, ResourceNotFoundError, RuntimeError, ValueError) as exc:
        parser.error(str(exc))
    print(json.dumps(result, ensure_ascii=True, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
