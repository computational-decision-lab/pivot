# Figure Status

0/14 preserved figure bundles reached `FINAL`; remaining bundles require an explicit hash-bound visual review.

| Figure | State | Bundle |
|---|---|---|
| `fig1_improvement_reversal` | `BLOCKED` | `figures/v15/fig1_improvement_reversal` |
| `fig2_operator_shift` | `BLOCKED` | `figures/v15/fig2_operator_shift` |
| `fig3_pivot_voi` | `BLOCKED` | `figures/v15/fig3_pivot_voi` |
| `fig4_evidence_efficiency` | `BLOCKED` | `figures/v15/fig4_evidence_efficiency` |
| `fig5_closed_loop` | `BLOCKED` | `figures/v15/fig5_closed_loop` |
| `fig6_world_response_decomposition` | `BLOCKED` | `figures/v15/fig6_world_response_decomposition` |
| `fig7_learned_ood_null` | `BLOCKED` | `figures/v15/fig7_learned_ood_null` |
| `fig8_voi_robustness` | `BLOCKED` | `figures/v15/fig8_voi_robustness` |
| `fig9_strategic_generalization` | `BLOCKED` | `figures/v15/fig9_strategic_generalization` |
| `figE_finance_boundary` | `BLOCKED` | `figures/v15/figE_finance_boundary` |
| `figA_response_footprint` | `BLOCKED` | `figures/v15/figA_response_footprint` |
| `figB_learned_ood_null` | `BLOCKED` | `figures/v15/figB_learned_ood_null` |
| `figC_posterior_robustness` | `BLOCKED` | `figures/v15/figC_posterior_robustness` |
| `figD_strategic_distribution` | `BLOCKED` | `figures/v15/figD_strategic_distribution` |
