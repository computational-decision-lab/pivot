from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest


class FakeClient:
    def __init__(self, records: list[dict]) -> None:
        self.records = records
        self.calls: list[tuple[str, str]] = []

    def describe_instances(self, instance_ids=None):
        wanted = set(instance_ids or [])
        if not wanted:
            return {"InstanceSet": self.records}
        return {"InstanceSet": [r for r in self.records if r.get("InstanceId") in wanted]}

    def start_instances(self, instance_ids):
        self.calls.append(("start", instance_ids[0]))
        return {"RequestId": "request-start"}

    def stop_instances(self, instance_ids):
        self.calls.append(("stop", instance_ids[0]))
        return {"RequestId": "request-stop"}

    def terminate_instances(self, instance_ids):
        self.calls.append(("release", instance_ids[0]))
        return {"RequestId": "request-release"}


def record(instance_id: str = "ins-safe") -> dict:
    return {
        "InstanceId": instance_id,
        "InstanceState": "STOPPED",
        "InstanceType": "SA5.2XLARGE16",
        "Tags": [{"Key": "owner", "Value": "research"}, {"Key": "project", "Value": "pivot"}],
        "SecretKey": "must-not-appear",
    }


def test_protected_instance_is_rejected_before_any_mutation() -> None:
    from pivot.cloud.tencent_lifecycle import ProtectedResourceError, TencentResourceLifecycle

    client = FakeClient([record("ins-5qak5eao")])
    lifecycle = TencentResourceLifecycle(client)

    with pytest.raises(ProtectedResourceError):
        lifecycle.mutate(
            "stop",
            "ins-5qak5eao",
            owner="research",
            tags={"project": "pivot"},
            dry_run=False,
        )

    assert client.calls == []


def test_mutation_requires_owner_and_tag_match() -> None:
    from pivot.cloud.tencent_lifecycle import AuthorizationError, TencentResourceLifecycle

    client = FakeClient([record()])
    lifecycle = TencentResourceLifecycle(client)

    with pytest.raises(AuthorizationError):
        lifecycle.mutate("stop", "ins-safe", owner="other", tags={"project": "pivot"})
    with pytest.raises(AuthorizationError):
        lifecycle.mutate("stop", "ins-safe", owner="research", tags={"project": "other"})
    assert client.calls == []


def test_dry_run_is_default_and_does_not_call_mutation() -> None:
    from pivot.cloud.tencent_lifecycle import TencentResourceLifecycle

    client = FakeClient([record()])
    result = TencentResourceLifecycle(client).mutate(
        "stop", "ins-safe", owner="research", tags={"project": "pivot"}
    )

    assert result == {
        "action": "stop",
        "instance_id": "ins-safe",
        "dry_run": True,
        "authorized": True,
    }
    assert client.calls == []


def test_describe_sanitizes_secret_like_fields() -> None:
    from pivot.cloud.tencent_lifecycle import TencentResourceLifecycle

    result = TencentResourceLifecycle(FakeClient([record()])).describe()
    dumped = json.dumps(result)
    assert "must-not-appear" not in dumped
    assert "SecretKey" not in dumped
    assert result["instances"][0]["InstanceId"] == "ins-safe"


def test_cli_requires_explicit_execute_for_mutating_actions() -> None:
    completed = subprocess.run(
        [
            sys.executable,
            "scripts/tencent_resources.py",
            "--action",
            "stop",
            "--instance-id",
            "ins-5qak5eao",
            "--owner",
            "research",
            "--tag",
            "project=pivot",
        ],
        cwd=Path(__file__).parents[2],
        capture_output=True,
        text=True,
        check=False,
    )

    assert completed.returncode != 0
    assert "--execute" in completed.stderr
    assert "Secret" not in completed.stderr
